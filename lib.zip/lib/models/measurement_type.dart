enum MeasurementType {
  quantity,   // Para contagem de vezes (1x ou múltiplas)
  minutes,    // Para contagem de minutos
}
