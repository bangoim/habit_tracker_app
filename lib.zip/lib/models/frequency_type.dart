enum FrequencyType {
  daily,
  weekly,
  monthly
}
