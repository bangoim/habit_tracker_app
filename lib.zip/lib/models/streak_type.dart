enum StreakType {
  daily,   // Precisa fazer todos os dias
  weekly,  // Precisa completar X vezes na semana
}
